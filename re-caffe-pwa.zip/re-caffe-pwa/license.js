/* ============================================================================
   RÈ-CAFFE — وحدة التحقق من الترخيص (تعمل دون إنترنت)
   تتحقق من توقيع رقمي ECDSA P-256 / SHA-256 باستخدام المفتاح العام أدناه.
   المفتاح الخاص (الذي يُنشئ المفاتيح) موجود فقط في keygen.html ولا يُوزَّع للعملاء.
   ----------------------------------------------------------------------------
   للإنتاج: ولّد زوج مفاتيح جديداً من keygen.html ثم استبدل القيمة أدناه
   بـ «المفتاح العام» الذي يعرضه المولّد. لا تشارك المفتاح الخاص مع أحد.
   ============================================================================ */
(function () {
  "use strict";

  // === المفتاح العام (SPKI / Base64) — استبدله بمفتاحك للإنتاج ===
  const PUBLIC_KEY_B64 =
    "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEf80wKD/pTL2gnCmBn8T14X3CHjjHDxrnFAKcx4xJkCA8z+vteqYiv4erqLDIuJThKJOo3HawJQKopUDsRNP6cw==";

  const STORE_KEY = "recaffe_license_v1";

  /* ---------- أدوات Base64 ---------- */
  function b64ToBuf(b64) {
    const bin = atob(b64);
    const u = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i);
    return u.buffer;
  }
  function b64urlToBuf(s) {
    s = String(s).replace(/-/g, "+").replace(/_/g, "/").replace(/\s+/g, "");
    while (s.length % 4) s += "=";
    return b64ToBuf(s);
  }

  /* ---------- التحقق من التوقيع ---------- */
  let _pubPromise = null;
  function getPublicKey() {
    if (!_pubPromise) {
      _pubPromise = crypto.subtle.importKey(
        "spki", b64ToBuf(PUBLIC_KEY_B64),
        { name: "ECDSA", namedCurve: "P-256" }, false, ["verify"]
      );
    }
    return _pubPromise;
  }

  async function verifyToken(token) {
    if (!crypto || !crypto.subtle) throw new Error("المتصفح لا يدعم التحقق الآمن (افتح عبر https أو localhost)");
    const parts = String(token).trim().split(".");
    if (parts.length !== 2 || !parts[0] || !parts[1]) throw new Error("صيغة المفتاح غير صحيحة");
    let payloadBytes, sigBytes;
    try {
      payloadBytes = b64urlToBuf(parts[0]);
      sigBytes = b64urlToBuf(parts[1]);
    } catch (e) { throw new Error("المفتاح غير قابل للقراءة"); }

    const key = await getPublicKey();
    const ok = await crypto.subtle.verify({ name: "ECDSA", hash: "SHA-256" }, key, sigBytes, payloadBytes);
    if (!ok) throw new Error("المفتاح غير صالح أو تمّ تعديله");

    let payload;
    try { payload = JSON.parse(new TextDecoder().decode(payloadBytes)); }
    catch (e) { throw new Error("بيانات الترخيص تالفة"); }

    if (payload.exp) {
      const end = new Date(payload.exp + "T23:59:59");
      if (!isNaN(end) && Date.now() > end.getTime())
        throw new Error("انتهت صلاحية الترخيص بتاريخ " + payload.exp);
    }
    return payload;
  }

  /* ---------- التحكّم بالبوابة ---------- */
  const $ = (id) => document.getElementById(id);
  function gateMsg(text, isErr) {
    const m = $("licMsg");
    if (m) { m.textContent = text || ""; m.style.color = isErr ? "#f87171" : "#34d399"; }
  }
  function setBusy(b) {
    const btn = $("licActivateBtn");
    if (btn) { btn.disabled = b; btn.style.opacity = b ? ".6" : "1"; btn.textContent = b ? "جارٍ التحقق…" : "🔓 تفعيل النظام"; }
  }
  function showGate() { const g = $("licenseGate"); if (g) g.style.display = "flex"; }
  function hideGate() { const g = $("licenseGate"); if (g) g.style.display = "none"; }

  function onLicensed(payload) {
    window.__RECAFFE_LICENSE = payload;
    hideGate();
    // اعرض اسم المرخَّص له في زاوية الشريط الجانبي إن وُجد العنصر
    const tag = $("licenseHolderTag");
    if (tag && payload) {
      const exp = payload.exp ? ("ينتهي " + payload.exp) : "ترخيص دائم";
      tag.textContent = "🔑 " + (payload.name || "مرخَّص") + " • " + exp;
    }
  }

  async function activateLicense() {
    const inp = $("licKey");
    const raw = (inp && inp.value ? inp.value : "").trim();
    if (!raw) { gateMsg("الصق مفتاح التفعيل أولاً", true); return; }
    setBusy(true);
    try {
      const payload = await verifyToken(raw);
      try { localStorage.setItem(STORE_KEY, raw); } catch (e) {}
      gateMsg("تم التفعيل بنجاح ✓", false);
      setTimeout(() => onLicensed(payload), 450);
    } catch (e) {
      gateMsg(e.message || "فشل التفعيل", true);
    } finally {
      setBusy(false);
    }
  }

  // واجهة عامة بسيطة للإدارة (مثلاً زر «إلغاء التفعيل» في الإعدادات)
  window.RECAFFE_LICENSE = {
    info: function () { return window.__RECAFFE_LICENSE || null; },
    verify: verifyToken,
    deactivate: function () {
      try { localStorage.removeItem(STORE_KEY); } catch (e) {}
      location.reload();
    }
  };
  window.activateLicense = activateLicense;

  /* ---------- الإقلاع ---------- */
  document.addEventListener("DOMContentLoaded", async function () {
    const btn = $("licActivateBtn");
    if (btn) btn.addEventListener("click", activateLicense);
    const inp = $("licKey");
    if (inp) inp.addEventListener("keydown", (e) => { if (e.key === "Enter") { e.preventDefault(); activateLicense(); } });

    let token = null;
    try { token = localStorage.getItem(STORE_KEY); } catch (e) {}
    if (token) {
      try { const p = await verifyToken(token); onLicensed(p); return; }
      catch (e) { gateMsg("الترخيص المحفوظ: " + e.message, true); }
    }
    showGate();
  });
})();
