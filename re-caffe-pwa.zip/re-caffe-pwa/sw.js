/* RÈ-CAFFE — Service Worker
   استراتيجية: تخزين مُسبق لهيكل التطبيق + عمل دون إنترنت.
   ملاحظة: عند أي تعديل على ملفات التطبيق، ارفع رقم الإصدار CACHE_VERSION
   حتى يحدّث المتصفح النسخة المخزّنة لدى المستخدمين. */
const CACHE_VERSION = "re-caffe-v2";
const CORE = [
  "./",
  "./index.html",
  "./license.js",
  "./i18n.js",
  "./manifest.webmanifest",
  "./icons/icon-192.png",
  "./icons/icon-512.png",
  "./icons/icon-maskable-512.png",
  "./icons/favicon-64.png"
];

// تثبيت: خزّن هيكل التطبيق
self.addEventListener("install", (e) => {
  e.waitUntil(
    caches.open(CACHE_VERSION).then((c) => c.addAll(CORE)).then(() => self.skipWaiting())
  );
});

// تفعيل: احذف النسخ القديمة
self.addEventListener("activate", (e) => {
  e.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE_VERSION).map((k) => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});

// السماح بتفعيل تحديث فوري من الصفحة
self.addEventListener("message", (e) => {
  if (e.data === "SKIP_WAITING") self.skipWaiting();
});

self.addEventListener("fetch", (e) => {
  const req = e.request;
  if (req.method !== "GET") return;
  const url = new URL(req.url);

  // طلبات التنقّل (فتح التطبيق) → جرّب الشبكة ثم ارجع للنسخة المخزّنة دون إنترنت
  if (req.mode === "navigate") {
    e.respondWith(
      fetch(req).catch(() => caches.match("./index.html"))
    );
    return;
  }

  // خطوط Google (Tajawal) → خزّنها وقت التشغيل لتعمل دون إنترنت لاحقاً
  if (url.origin.includes("fonts.googleapis.com") || url.origin.includes("fonts.gstatic.com")) {
    e.respondWith(
      caches.open(CACHE_VERSION + "-fonts").then(async (cache) => {
        const cached = await cache.match(req);
        if (cached) return cached;
        try {
          const res = await fetch(req);
          if (res.ok) cache.put(req, res.clone());
          return res;
        } catch (err) {
          return cached || Response.error();
        }
      })
    );
    return;
  }

  // باقي الملفات (نفس النطاق) → النسخة المخزّنة أولاً، ثم الشبكة، مع تحديث الكاش
  if (url.origin === self.location.origin) {
    e.respondWith(
      caches.match(req).then((cached) => {
        const live = fetch(req).then((res) => {
          if (res && res.ok) {
            const copy = res.clone();
            caches.open(CACHE_VERSION).then((c) => c.put(req, copy));
          }
          return res;
        }).catch(() => cached);
        return cached || live;
      })
    );
  }
});
